#!/usr/bin/env ruby
#
#  Created by Jim Weirich on 2007-04-14.
#  Copyright (c) 2007. All rights reserved.

require 'flexmock/noop'

class FlexMock

end